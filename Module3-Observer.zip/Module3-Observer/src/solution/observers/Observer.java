package solution.observers;

public interface Observer {
	public void update(Subject subject, int value);
}
