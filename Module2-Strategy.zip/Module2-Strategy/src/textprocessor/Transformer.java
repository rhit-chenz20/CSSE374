package textprocessor;

public interface Transformer {
	String transform(String text);
}
